#!/bin/bash

DBNAME="xucl"
TBLCNT=40
WARMUP=300
DURING=3600

# 并发压测的线程数，根据机器配置实际情况进行调整
RUN_NUMBER="8 16 32 64 128"
RUN_PCT="80 60 40 20"

round=1
# 一般至少跑3轮测试，我正常都会跑10轮以上
while [ $round -lt 4 ]
do

rounddir=iobenchmary-logs-round${round}
mkdir -p /tmp/${rounddir}

for thread in `echo "${RUN_NUMBER}"`
do
	for rwpct in `echo "${RUN_PCT}"`
	do
	/usr/local/bin/fio -filename=/storage/test_randread -direct=1 \
	-iodepth=64 -thread -rw=randrw -rwmixread=${rwpct} -ioengine=psync -bs=16k \
	-size=200G -numjobs=${thread} -runtime=3600 -group_reporting -name=mytest >> /tmp/${rounddir}/xucl_${thread}_${rwpct}.log

sleep 120
done
done

round=`expr $round + 1`
sleep 120
done
