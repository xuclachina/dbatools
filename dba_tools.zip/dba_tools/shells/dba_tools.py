#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/28 14:02
# @Author  : xucl
# @Email   : xuchenliang123@live.com
# @File    : dba_tools.py
# @Software: PyCharm

import os
import sys
import time

list_a = ['1', '2', '3', '4']
while True:
    a = raw_input("""
    请输入需要安装的软件(按q退出)：
    1.pt-tools
    2.xtrabackup
    3.sysbench
    4.fio
    """)
    if a == 'q':
        break
    elif a not in list_a:
        print("输入有误，请重新输入！")
        continue
    elif a == '1':
        if os.path.exists('/usr/local/bin/pt-kill'):
            print('pt-tools已安装')
        else:
            print("开始安装pt-tools")
            print("依赖包安装...")
            time.sleep(1)
            try:
                cmd = "yum install perl-DBI perl-DBD-MySQL perl-Time-HiRes perl-IO-Socket-SSL perl-Digest-MD5.x86_64 perl-TermReadKey -y"
                os.system(cmd)
                cmd2 = "rpm -ivh ../packages/percona-toolkit-3.0.12-1.el6.x86_64.rpm"
                os.system(cmd2)
                print("pt-tools安装完成！")
            except Exception as e:
                print(e)
                sys.exit(0)
    elif a == '2':
        if os.path.exists('/usr/bin/xtrabackup'):
            print('xtrabackup已安装')
        else:
            print("开始安装xtrabackup")
            print("依赖包安装...")
            time.sleep(1)
            try:
                cmd = "yum install -y perl-DBD-MySQL perl-Digest-MD5 perl-DBI perl-Time-HiRes perl-IO-Socket-SSL libev-devel rsync"
                os.system(cmd)
                cmd2 = "rpm -ivh ../packages/percona-xtrabackup-24-2.4.8-1.el7.x86_64.rpm"
                os.system(cmd2)
                print("xtrabackup安装完成！")
            except Exception as e:
                print(e)
                sys.exit(0)
    elif a == '3':
        if os.path.exists('/usr/local/bin/sysbench'):
            print('sysbench已安装')
        else:
            print("开始安装sysbench")
            print("依赖包安装...")
            time.sleep(1)
            try:
                cmd = "yum install autoconf automake libtool -y"
                os.system(cmd)
                cmd2 = "tar -zxvf ../packages/sysbench-1.0.16.tar.gz -C /usr/local/src"
                os.chdir("/usr/local/src/sysbench-1.0.16")
                os.system("./autogen.sh")
                os.system("./configure")
                os.system("make -j")
                os.system("make install")
                print("sysbench安装完成！")
            except Exception as e:
                print(e)
                sys.exit(0)
    else:
        if os.path.exists('/usr/local/bin/fio'):
            print('fio已安装')
        else:
            print("开始安装fio")
            print("依赖包安装...")
            time.sleep(1)
            try:
                cmd2 = "tar -zxvf ../packages/fio-2.1.10.tar.gz -C /usr/local/src"
                os.chdir("/usr/local/src/fio-2.1.10")
                os.system("make")
                os.system("make install")
                print("fio安装完成！")
            except Exception as e:
                print(e)
                sys.exit(0)
