vip="192.168.1.100/32"
/sbin/ip addr add $vip dev eth0
